package com.tur.job1.others;

public class ConstantsHolder {

    public static String rawServer = "http://192.168.70.165:8080/";

    public static String phoneCheck = "UserCheck";
    public static String signupUser = "UserSignUp";
}
